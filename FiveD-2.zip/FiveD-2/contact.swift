//
//  contact.swift
//  FiveD
//
//  Created by Mazen on 02/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
import Alamofire
class Contact: UIViewController{
    let user = User10(json: JSON.null)
    @IBOutlet weak var contctImg1: UIImageView!
    
    @IBOutlet weak var contactImg2: UIImageView!
    @IBOutlet weak var cont: UIImageView!
    @IBOutlet weak var conactUs: UILabel!
    
    func contact () {
    
    let url = user!.Api + "/\(user!.id)"

        conactUs.text = " You can contact Us on" + user!.phone + "or Using our Email at " + user!.emailAddres
        }
            
    @IBAction func messageUs(_ sender: Any) {
        
    }
    }
