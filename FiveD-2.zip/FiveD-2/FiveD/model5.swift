//
//  model5.swift
//  FiveD
//
//  Created by Mazen on 05/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import SwiftyJSON
import UIKit
import Kingfisher
import Alamofire
class User5 : NSObject {
let Api = "http://schoolms-001-site1.ctempurl.com/api/GetAttendanceDataBySchoolId/"

   var id :Int
   var schoolID :Int?
   var CalenderTypeId : Int?
       var AttendanceImage : URL


   var createdAt: [String: Any]?
   
   required init?( json: JSON) {
       self.id = json["Id"].int!
       self.CalenderTypeId = json["CalenderTypeId"].int
       self.schoolID = json ["SchoolId"].int
       self.AttendanceImage = json ["AttendanceImage"].url!
   
       }
}
