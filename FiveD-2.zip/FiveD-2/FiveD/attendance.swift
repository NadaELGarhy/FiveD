//
//  attendance.swift
//  FiveD
//
//  Created by Mazen on 02/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//
import Foundation
import UIKit
import Alamofire
import SwiftyJSON
class Attendance: UIViewController{
    let user = User5(json: JSON.null)

   
    @IBOutlet weak var attendanceImg: UIImageView!
    @IBOutlet weak var noData2: UILabel!
    @IBOutlet weak var noData: UILabel!

    @IBOutlet weak var weekly: UIImageView!
    
    @IBOutlet weak var monthly: UIImageView!

    @IBAction func weeklyAttendance(_ sender: Any){
        let url = user!.Api + "/\(user!.id)"

        if user!.CalenderTypeId == 1 {
            weekly.kf.setImage(with: user!.AttendanceImage)
        }
        else {
            weekly.image = nil
        }}
    @IBAction func monthlyAttendance(_ sender: Any) {
                if user!.CalenderTypeId == 2 {
                             monthly.kf.setImage(with: user!.AttendanceImage)
                         }
                         else {
                             monthly.image = nil
               }
           }
    }
    
    

