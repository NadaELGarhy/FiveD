//
//  model4.swift
//  FiveD
//
//  Created by Mazen on 05/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import SwiftyJSON
import UIKit
import Kingfisher
import Alamofire
class User4 : NSObject {
     let Api = "http://schoolms-001-site1.ctempurl.com/api/GetScheduleDataBySchoolID/3"

 var id :Int
 var schoolID :Int?
 var ScheduletypeID : Int?
     var ScheduleImage : URL
 



 var createdAt: [String: Any]?
 
 required init?( json: JSON) {
     self.id = json["Id"].int!
     self.ScheduletypeID = json["ScheduleTypeId"].int
     self.schoolID = json ["SchoolId"].int
     self.ScheduleImage = json ["ScheduleImage"].url!
 
     }
}
