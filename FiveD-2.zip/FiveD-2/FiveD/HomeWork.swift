//
//  HomeWork.swift
//  FiveD
//
//  Created by Mazen on 04/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
import Alamofire
class HomeWorks : UIViewController{
    let user = User9(json: JSON.null)

    @IBOutlet weak var Hw: UIImageView!
    
    @IBOutlet weak var homeWorksImg: UIImageView!

              
    
        
    
    @IBOutlet weak var hwLbl: UILabel!
            
    func homework(){
    let url = user!.Api + "/\(user!.id)"

            
            hwLbl.text = " They have homework in " + user!.taskname + "as " + user!.taskdetails
        }
 
    
}
