//
//  Grades.swift
//  FiveD
//
//  Created by Mazen on 29/11/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
import Kingfisher
class Grade : UIViewController {
    let user = User3(json: JSON.null)

    
    @IBOutlet weak var gradesImg: UIImageView!
    @IBOutlet weak var noData: UILabel!
    
    @IBOutlet weak var noData2: UIImageView!

        @IBOutlet weak var finalImg: UIImageView!

    @IBOutlet weak var midImg: UIImageView!
    @IBAction func midtermGrades(_ sender: Any) {
        let url = user!.Api + "/\(user!.id)"
        if user!.GradetypeID == 1{
            midImg.kf.setImage(with: user!.gradimg)
        }
        else {
            midImg = nil
        }
        }
        
    
    @IBAction func finalGrades(_ sender: Any) {
        if user!.GradetypeID == 2 {
            finalImg.kf.setImage(with: user!.gradimg)
               }
               else {
                   midImg = nil
               }
               
        
    
}


}

