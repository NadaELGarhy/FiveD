//
//  Activity.swift
//  FiveD
//
//  Created by Mazen on 04/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//
import Foundation
import UIKit
import SwiftyJSON
import Alamofire

class Activities : UIViewController{
    let user = User7(json: JSON.null)

    
    @IBOutlet weak var activitiesImg: UIImageView!
    @IBOutlet weak var act: UIImageView!
    
    @IBOutlet weak var activityLbl: UILabel!
    func Adetails (){
        let url = user!.Api + "/\(user!.id)"

           activityLbl.text = user!.ActivityDescription
    
           
           }
}
