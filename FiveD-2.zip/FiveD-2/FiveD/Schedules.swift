//
//  Schedules.swift
//  FiveD
//
//  Created by Mazen on 29/11/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
import Kingfisher
class Schedule: UIViewController{
    let user = User4(json: JSON.null)

    @IBOutlet weak var scheduleImg: UIImageView!
    @IBOutlet weak var noData: UILabel!
    @IBOutlet weak var noData2: UILabel!
    
 

    @IBOutlet weak var examImg: UIImageView!
    @IBOutlet weak var classImg: UIImageView!
    
   @IBAction func classSchedule(_ sender: Any) {
    let url = user!.Api + "/\(user!.id)"
    if user!.ScheduletypeID == 1{
        classImg.kf.setImage(with: user!.ScheduleImage) }
    else {
        classImg.image = nil
            
    }}
    
    @IBAction func examSchedule(_ sender: Any) {
        if user!.ScheduletypeID == 2{
            examImg.kf.setImage(with: user!.ScheduleImage) }
        else {
            examImg.image = nil
                
        }
            
    }
    
}

