//
//  MidtermGrades.swift
//  FiveD
//
//  Created by Mazen on 29/11/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//
import UIKit
class MidtermGrades: UIViewController{
    
    var id: String!

    @IBOutlet weak var midTerm: UIImageView!
    
}
