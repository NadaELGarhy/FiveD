//
//  VC2.swift
//  FiveD
//
//  Created by X on 7/19/20.
//  Copyright © 2020 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

class VC2: UIViewController{
    
    var id: String!

    
       @IBAction func gradesAction(_ sender: Any) {
           let semaphore = DispatchSemaphore (value: 0)

           var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetGradeDataBySchoolID/{id}")!,timeoutInterval: Double.infinity)
           request.httpMethod = "GET"

           let task = URLSession.shared.dataTask(with: request) { data, response, error in
             guard let data = data else {
               print(String(describing: error))
               return
             }
             print(String(data: data, encoding: .utf8)!)
             semaphore.signal()
           }

           task.resume()
           semaphore.wait()

          

       }
       
    
    @IBAction func eventsAction(_ sender: Any) {
        let semaphore = DispatchSemaphore (value: 0)

        var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetEventDataBySchoolID/{id}")!,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
          guard let data = data else {
            print(String(describing: error))
            return
          }
          print(String(data: data, encoding: .utf8)!)
          semaphore.signal()
        }

        task.resume()
        semaphore.wait()

    
    }
    
    @IBAction func scheduleAction(_ sender: Any) {
         
        let semaphore = DispatchSemaphore (value: 0)
                  var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetScheduleDataBySchoolID/{id}")!,timeoutInterval: Double.infinity)
                  request.httpMethod = "GET"

                  let task = URLSession.shared.dataTask(with: request) { data, response, error in
                    guard let data = data else {
                      print(String(describing: error))
                      return
                    }
                    print(String(data: data, encoding: .utf8)!)
                    semaphore.signal()
                  }

                  task.resume()
                  semaphore.wait()
        
        
    }
    
    
    @IBAction func attendanceAction(_ sender: Any) {
    let semaphore = DispatchSemaphore (value: 0)
              var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetAttendanceDataBySchoolId/{id}")!,timeoutInterval: Double.infinity)
              request.httpMethod = "GET"

              let task = URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data else {
                  print(String(describing: error))
                  return
                }
                print(String(data: data, encoding: .utf8)!)
                semaphore.signal()
              }

              task.resume()
              semaphore.wait()
    
    
    }
    
    @IBAction func homeWorksAction(_ sender: Any) {
        let semaphore = DispatchSemaphore (value: 0)
                     var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetHomeWorkDataBySchoolID/{id}")!,timeoutInterval: Double.infinity)
                     request.httpMethod = "GET"

                     let task = URLSession.shared.dataTask(with: request) { data, response, error in
                       guard let data = data else {
                         print(String(describing: error))
                         return
                       }
                       print(String(data: data, encoding: .utf8)!)
                       semaphore.signal()
                     }

                     task.resume()
                     semaphore.wait()
    
    }
    
    @IBAction func reports(_ sender: Any) {
        let semaphore = DispatchSemaphore (value: 0)

        var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetReportDataBySchoolID/{id}")!,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
          guard let data = data else {
            print(String(describing: error))
            return
          }
          print(String(data: data, encoding: .utf8)!)
          semaphore.signal()
        }

        task.resume()
        semaphore.wait()
    }
    
    @IBAction func activities(_ sender: Any) {
        let semaphore = DispatchSemaphore (value: 0)

        var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/GetActivityDataBySchoolID/{id}")!,timeoutInterval: Double.infinity)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
          guard let data = data else {
            print(String(describing: error))
            return
          }
          print(String(data: data, encoding: .utf8)!)
          semaphore.signal()
        }

        task.resume()
        semaphore.wait()
    
    }

    @IBAction func contactUs(_ sender: Any) {
        let semaphore = DispatchSemaphore (value: 0)

        var request = URLRequest(url: URL(string: "http://schoolms-001-site1.ctempurl.com/api/PostMeetingRequestData")!,timeoutInterval: Double.infinity)
        request.httpMethod = "POST"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
          guard let data = data else {
            print(String(describing: error))
            return
          }
          print(String(data: data, encoding: .utf8)!)
          semaphore.signal()
        }

        task.resume()
        semaphore.wait()

    }
    
}
