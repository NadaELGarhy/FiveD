//
//  Report.swift
//  FiveD
//
//  Created by Mazen on 04/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
import Alamofire

class Reports : UIViewController{
    let user = User6(json: JSON.null)


    @IBOutlet weak var reportsImg: UIImageView!
    @IBOutlet weak var rep: UIImageView!
    @IBOutlet weak var reportsLbl: UILabel!
    func rdetails (){
        reportsLbl.text = user!.ReportDescription
 
       
    }}
