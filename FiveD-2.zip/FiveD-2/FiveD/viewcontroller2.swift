//
//  viewcontroller2.swift
//  FiveD
//
//  Created by Mazen on 02/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//


import Foundation
import UIKit
import Alamofire
import SwiftyJSON
class viewcontroller2: UIViewController{
    let user = User2(json: JSON.null)
    @IBOutlet weak var userData: UILabel!

    @IBOutlet weak var grades: UIButton!
    @IBOutlet weak var events: UIButton!
    @IBOutlet weak var schedules: UIButton!
    @IBOutlet weak var attendance: UIButton!
    @IBOutlet weak var homeWorks: UIButton!
    @IBOutlet weak var reports: UIButton!
    @IBOutlet weak var activities: UIButton!
    @IBOutlet weak var contactUs: UIButton!
        func userdata(){
            userData.text = user!.firstName
        }
    
}
