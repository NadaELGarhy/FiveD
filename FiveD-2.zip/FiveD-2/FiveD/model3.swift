//
//  model3.swift
//  FiveD
//
//  Created by Mazen on 05/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import SwiftyJSON
import UIKit
import Kingfisher
import Alamofire
   class User3 : NSObject {
       let Api = "http://schoolms-001-site1.ctempurl.com/api/GetGradeDataBySchoolID/"
        var id : Int?
        var schoolID :Int?
        var GradetypeID : Int?
        var gradimg :URL!
   
        var createdAt: [String: Any]?
        
        required init?( json: JSON) {
            self.id = json["Id"].int
            self.GradetypeID = json["GradeTypeId"].int
            self.schoolID = json ["SchoolId"].int
           self.gradimg = json ["GradeImage"].url!

            }
}
