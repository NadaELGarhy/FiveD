//
//  webservice.swift
//  FiveD
//
//  Created by Mazen on 02/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import SwiftyJSON
import UIKit
import Kingfisher
import Alamofire

class User9 : NSObject {
    let Api = "http://schoolms-001-site1.ctempurl.com/api/GetHomeWorkDataBySchoolID/"
    var id : Int?
    var schoolID :Int?
    var taskname :String
    var taskdetails :String
    var courseId :String
    var courseName :String
    var courseCode :String
    var semesterId :Int
    
var createdAt: [String: Any]?

required init?( json: JSON) {
    self.id = json["Id"].int
    self.schoolID = json ["SchoolId"].int
    self.taskname = json["TaskName"].string!
    self.taskdetails = json ["TaskDetails"].string!
    self.courseId = json["CourseId"].string!
    self.courseCode = json["CourseCode"].string!
    self.courseName = json ["CourseName"].string!
    self.semesterId = json ["SemesterId"].int!
    
        
        
        
        
        
        
        
        
        
        
    }
}
