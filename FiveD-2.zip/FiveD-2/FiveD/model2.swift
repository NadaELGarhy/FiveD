//
//  model2.swift
//  FiveD
//
//  Created by Mazen on 05/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import SwiftyJSON
import UIKit
import Kingfisher
import Alamofire

class User2 :NSObject {
       let Api = "http://schoolms-001-site1.ctempurl.com/api/GetParentsDataByID"
           var firstName : String?
           var lastName : String?
          var createdAt: [String: Any]?
          required init?( json: JSON) {
              self.firstName = json ["Fname"].string
              self.lastName = json ["Lname"].string
    }}
