//
//  ViewController.swift
//  FiveD
//
//  Created by Mazen Magdy on 1/26/20.
//  Copyright © 2020 Mazen Magdy. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import Kingfisher
class ViewController: UIViewController {
    let user = User1(json: JSON.null)
    

    @IBOutlet weak var userName: UITextField!
    
    @IBOutlet weak var userPassword: UITextField!
    @IBOutlet weak var inCorrect: UILabel!
    @IBAction func signIn(_ sender: Any) {
        let url = user!.Api + "\(userName.text)" + "&Password=" + "\(userPassword.text)"
        if user!.codee == 200 {
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                   let home = storyboard.instantiateViewController (withIdentifier: "viewcontroller2") as! viewcontroller2
          navigationController?.pushViewController(home, animated: true)
        }
        else{
            inCorrect.text = "Please check your Cradentials"
        }
        
        }
    override func viewDidLoad() {
    super.viewDidLoad()
            // Do any additional setup after loading the view.
    }
}
