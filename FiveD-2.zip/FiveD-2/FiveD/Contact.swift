//
//  Contact.swift
//  FiveD
//
//  Created by Mazen on 02/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
