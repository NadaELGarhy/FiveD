//
//  model10.swift
//  FiveD
//
//  Created by Mazen on 05/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import SwiftyJSON
import UIKit
import Kingfisher
import Alamofire
class User10 : NSObject {
    let Api = "http://schoolms-001-site1.ctempurl.com/api/GetMeetingRequestDataBySchoolID/"
    var id : Int?
    var schoolID :Int?
    var name :String
    var phone :String
    var emailAddres :String
    var title :String
    var message :String
    var createdAt: [String: Any]?

    required init?( json: JSON) {
        self.id = json["Id"].int
        self.name = json["Name"].string!
        self.phone = json["Mobile"].string!
        self.emailAddres = json["email"].string!
        self.schoolID = json ["SchoolId"].int
        self.title = json ["Title"].string!
        self.message = json ["Message"].string!
}
}
