//
//  Event.swift
//  FiveD
//
//  Created by Mazen on 04/12/1441 AH.
//  Copyright © 1441 Mazen Magdy. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON
import Alamofire
class Events : UIViewController {
    let user = User8(json: JSON.null)

    
    @IBOutlet weak var eventsImg: UIImageView!
    @IBOutlet weak var event: UIImageView!
    
   
    @IBOutlet weak var eventDetails: UILabel!
    func detail() {
        let url = user!.Api + "/\(user!.id)"

        eventDetails.text = user!.EventDescription
    }}
